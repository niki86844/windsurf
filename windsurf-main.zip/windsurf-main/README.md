# Gestion Immobilière – Phase 1

Cette application no-code a été générée pour la gestion immobilière sur Windsurf.

## Fonctionnalités Phase 1
- Page de connexion sécurisée (login + 2FA)
- Dashboard résumé
- Ajout de biens et de locataires
- Impression, export PDF, envoi par email, stockage cloud

## Structure du projet
- `login.page.json` : Page de connexion
- `dashboard.page.json` : Tableau de bord
- `add_property.form.json` : Formulaire ajout bien
- `add_tenant.form.json` : Formulaire ajout locataire
- `forgot_password.page.json` : Mot de passe oublié
- `styles.print.css` : Styles pour impression

---
Généré automatiquement. Modifier les pages via l’éditeur Windsurf.
